package com.example.activitytest.network;


import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UploadUtil {
    private static final String TAG = "uploadFile";
    private static final int TIME_OUT = 10*1000;   //��ʱʱ��
    private static final String CHARSET = "utf-8"; //���ñ���
    /**
     * android�ϴ��ļ���������
     * @param file  ��Ҫ�ϴ����ļ�
     * @param RequestURL  �����rul
     * @return  ������Ӧ������
     */
    public static String uploadFile(File file,String actionUrl)
    {
        String result = null;

    	String newName = file.getName();
    	String uploadFile = file.getPath();
        String end = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        try {
            URL url = new URL(actionUrl);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            /* ����Input��Output����ʹ��Cache */
            con.setDoInput(true);
            con.setDoOutput(true);
            con.setUseCaches(false);
 
            // ����http��������
            con.setRequestMethod("POST");
            con.setRequestProperty("Connection", "Keep-Alive");
            con.setRequestProperty("Charset", "UTF-8");
            con.setRequestProperty("Content-Type",
                    "multipart/form-data;boundary=" + boundary);
 
            DataOutputStream ds = new DataOutputStream(con.getOutputStream());
            ds.writeBytes(twoHyphens + boundary + end);
            ds.writeBytes("Content-Disposition: form-data; "
                    + "name=\"file1\";filename=\"" + newName + "\"" + end);
            ds.writeBytes(end);
 
            // ȡ���ļ���FileInputStream
            FileInputStream fStream = new FileInputStream(uploadFile);
            /* ����ÿ��д��1024bytes */
            int bufferSize = 1024;
            byte[] buffer = new byte[bufferSize];
            int length = -1;
            /* ���ļ���ȡ������������ */
            while ((length = fStream.read(buffer)) != -1) {
                /* ������д��DataOutputStream�� */
                ds.write(buffer, 0, length);
            }
            ds.writeBytes(end);
            ds.writeBytes(twoHyphens + boundary + twoHyphens + end);
 
            fStream.close();
            ds.flush();
            /* ȡ��Response���� */
            InputStream is = con.getInputStream();
            int ch;
            StringBuffer b = new StringBuffer();
            while ((ch = is.read()) != -1) {
                b.append((char) ch);
            }
            /* ��Response��ʾ��Dialog */
            result = b.toString();
            Log.e("dialog","�ϴ��ɹ�" + b.toString().trim());
            /* �ر�DataOutputStream */
            ds.close();
        } catch (Exception e) {
            Log.e("dialog","�ϴ�ʧ��" + e);

        }
        
        return result;
    }
 

}
